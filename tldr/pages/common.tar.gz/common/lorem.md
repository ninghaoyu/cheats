# lorem

> Create more or less random lorem ipsum text.

- Print the specified number of words:

`lorem -n {{20}}`

- Print 10 lines of Goethe's Faust:

`lorem -l {{10}} --faust`

- Print 5 sentences of Poe's Raven:

`lorem -s {{5}} --raven`

- Print 40 random characters from Boccacio's Decameron:

`lorem --randomize -c {{40}} --decamerone`
