# vue serve

> A subcommand provided by `@vue/cli` and `@vue/cli-service-global` that enables quick prototyping.
> More information: <https://cli.vuejs.org/guide/prototyping.html>.

- Serve a `.js` or `.vue` file in development mode with zero config:

`vue serve {{filename}}`
