# true

> Returns a successful exit status code of 0.
> Use this with the || operator to make a command always exit with 0.

- Return a successful exit code:

`true`
